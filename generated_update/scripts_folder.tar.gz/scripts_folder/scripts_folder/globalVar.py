import Queue
import datetime
import string,cgi,time
import codecs #to save and open utf8 files

from signal import signal, SIGPIPE, SIG_DFL  # to prevent [Errno 32] Broken pipe
import unicodedata
import os,sys,datetime

from os import curdir, sep
import BaseHTTPServer
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
from time import gmtime, strftime

import json
import unicodedata
import os
import codecs
#import urllib2,urllib 
import urllib2
#import httplib
import thread,threading,time
import os.path
import random
import binascii  #used by weobject class for the permission 
import re  #regular expression
import smtplib   #used by mail_agent to send mail

# Add vendor directory to module search path
lib_dir = os.path.join('external_libraries')
sys.path.append(lib_dir)
# Now you can import any library located in the "vendor" folder!
import urllib3
from urllib3 import PoolManager ,Timeout
#use example urllib3
#url_request_manager = PoolManager(10)
#url_request_manager=PoolManager(10)
#r = url_request_manager.request('GET', 'http://example.com')
#or
#r=url_request_manager.request_encode_body('POST','url',fields,timeout=Timeout(total=5.0))
#print r.data
#
# r = url_request_manager.request('GET', 'http://example.com:80',timeout=Timeout(total=5.0))

url_request_manager = PoolManager(8)


exit=0
debug=1  #debug mode , if set to 1  the debug mode is on 
object_dict={} #object_dict  contain all the web_object  and the key of the dictionary for each web_object is the name of the web_object
zoneDict={}#dict where the key is the name from roomList and the value is a list of all the webobject names present in the room  
router_hardware={}
scenarioDict={}


timezone="CET-1CEST,M3.5.0,M10.5.0/3"  #will be overwritten by /scripts_folder/config_files/cf.json
os.environ['TZ']=timezone 
try:
  time.tzset()
except:
  print "tzset not present , timezone will work anyway"
#time_gap=120    #minutes of difference between utc and local time 
#export TZ="CET-1CEST,M3.5.0,M10.5.0/3"



user_active_time_dict={}
login_required=1  #if setted to 1 enable the webpage login  and allow only logged user to use onos
logTimeout=15 #minutes of user inactivity before logout , will be overwritten by /scripts_folder/config_files/cf.json

log_name="file.log"
error_log_name="erros.log"
log_enable=0   #enable the log file size check
check_log_len_time=datetime.datetime.today().minute
mail_error_log_enable=1  #enable onos to send mail when an error happens
error_log_mail_frequency=60  #seconds between a error len() check and another
last_error_check_time=0
mail_where_to_send_errors="electronicflame@gmail.com"

baseRoomPath="zones/"
hardwareModelDict={}

#read_onos_sensor_enabled=1
router_sn="RouterGL0000"
router_hardware_type="RouterGL" #select the type of hardware
router_hardware_fw_version="5.14"
gui_webserver_port=80
service_webserver_port=81
service_webserver_delay=1 #seconds of delay between each answer
node_webserver_port=9000   # the web server port used on remote nodes
router_read_pin_frequency=20  #seconds between a pin read in the router hardware
last_pin_read_time=0


if (os.path.exists("/sys/class/gpio")==1)&(router_hardware_type=="RouterGL") : #if the directory exist ,then the hardware has embedded IO pins
  discovered_running_hardware=router_hardware_type
  base_cfg_path="/bin/onos/scripts_folder/"
else:
  discovered_running_hardware="pc"  #the hardware has not IO pins
  base_cfg_path=""




accept_only_from_white_list=0  #if set to 1 the onos cmd will be accepted only from mail in white list
#will be overwritten by /scripts_folder/config_files/cf.json

mail_whiteList=[]  #will be overwritten by /scripts_folder/config_files/cf.json
mail_whiteList.append("elettronicaopensource@gmail.com")
mail_whiteList.append("electronicflame@gmail.com")
mail_whiteList.append("marco_righe@yahoo.it")
enable_mail_service=1  #active mailCheckThread   will be overwritten by /scripts_folder/config_files/cf.json
last_mail_sync_time=0  
mailCheckThreadIsrunning=0 # tell onos if the mail thread is alredy running
mail_service=0
mail_check_frequency=10  #seconds between 2 checks
mailOutputHandler_is_running=0  #tell onos if the thread is already running


enable_onos_auto_update="yes" # possible value: "yes","no","ask_me"

online_server_enable=1  #enable the remote online server to controll onos from internet without opening the router ports
#will be overwritten by /scripts_folder/config_files/cf.json

last_server_sync_time=0
onlineServerSyncThreadIsrunning=0 #tell onos if the thread is running
online_server_delay=3   #seconds between each server query
online_object_dict=[]   #online object dict ,used to know if an update of the dict is needed
online_zone_dict=[]   #online zone dict ,used to know if an update of the dict is needed
if online_server_enable==1 :
  force_online_sync_users=1    #used to know if an update of the dict is required
else:
  force_online_sync_users=0    #used to know if an update of the dict is required
online_usersDict={}
online_first_contact=1  #tell if is the fist contact between this router and the online server
onos_online_key=router_sn  #unique key used by the router to login on the online server 
onos_online_password="1234"  #password used by the router to login on the online server 
onos_online_site_url="http://www.myonos.com/onos/"  #remote online server url (where the php onos scripts are located)

internet_connection=0  #tell onos if there is internet connection, do not change it..onos will change it if there is internet

layerExchangeDataQueue = Queue.Queue()  # this queue will contain all the dictionaries to pass data from the hardware layer to the webserver layer   router_handler.py will pass trought this queue all the change of hardware status to the webserver.py

mailQueue=Queue.Queue()  # this queue will contain all the mail to send , onos will send them as soon as possible

errorQueue=Queue.Queue()  # this queue will contain all the error happened


if enable_mail_service==1: 
  import imaplib   #used by mail_agent 
  import email     #used by mail_agent 
   








#scenarioDict["scenario1"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":1,"autodelete":0,"actType":"delay","conditions":"#_dayTime_#>0","functionsToRun":["socket0_RouterGL0001=1"],"afterDelayFunctionsToRun":["button0_RouterGL0001=1"],"delayTime":1,"priority":0}


#scenarioDict["scenario2"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"#_dayTime_#>0","functionsToRun":["onosCenterWifi=0],"priority":0}

#scenarioDict["scenario3"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==12)&(#_minutes_#==0)","functionsToRun":["onosCenterWifi=1"],"priority":0}



#banana to remove
scenarioDict["scenario2"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==8)&(#_minutes_#==0)","functionsToRun":["button0_RouterGL0000=1","Wifi_netgear==1","Caldaia=0"],"priority":0}

scenarioDict["scenario3"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==8)&(#_minutes_#==25)","functionsToRun":["button0_RouterGL0000=0","Wifi_netgear==0"],"priority":0}



scenarioDict["scenario4"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==12)&(#_minutes_#==30)","functionsToRun":["button0_RouterGL0000=1","Wifi_netgear==1"],"priority":0}



scenarioDict["scenario5"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==14)&(#_minutes_#==0)","functionsToRun":["button0_RouterGL0000=0","Wifi_netgear==0"],"priority":0}



scenarioDict["scenario6"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==18)&(#_minutes_#==0)","functionsToRun":["button0_RouterGL0000=1","Wifi_netgear==1"],"priority":0}


scenarioDict["scenario7"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==0)&(#_minutes_#==0)","functionsToRun":["button0_RouterGL0000=0","Wifi_netgear==0","counter1=0"],"priority":0}


scenarioDict["scenario8"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_minutes_#>-1)","functionsToRun":["wifi0_Plug6way0001=!#_wifi0_Plug6way0001_#","button1_RouterGL0000==!#_wifi0_Plug6way0001_#"],"priority":0}

scenarioDict["scenario9"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"1","functionsToRun":["counter1=#_counter1_#+1"],"priority":0}


scenarioDict["scenario10"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"(#_hours_#==23)&(#_minutes_#==0)","functionsToRun":["Caldaia=0"],"priority":0}




#6   sp 8   ,17on 11 off



#scenarioDict["scenario10"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"1","functionsToRun":["socket0_Plug6way0002=#_Wifi_netgear_#"],"priority":0}

#scenarioDict["scenario11"]={"enabled":1,"setType":"condition_to_set_status","one_time_shot":0,"autodelete":0,"actType":"nodelay","conditions":"1","functionsToRun":["socket1_Plug6way0002=#_Caldaia_#"],"priority":0}


#scenarioDict["scenario2"]={"enabled":1,"setType":"condition_to_set_status","autodelete":0,"actType":"delay","conditions":"#_dayTime_#>0","functionsToRun":["button1_RouterGL0001=1"],"afterDelayFunctionsToRun":["button0_RouterGL0001=0"],"delayTime":1,"priority":0}



nodeDict={}
usersDict={}
usersDict["onos_mail_guest"]={"pw":"onos","mail_control_password":"onosm","priority":0,"user_mail":"elettronicaopensource@gmail.com"}
usersDict["web_interface"]={"pw":"onos","mail_control_password":"onosm","priority":0,"user_mail":"elettronicaopensource@gmail.com"}
usersDict["scenario"]={"pw":"onos","mail_control_password":"onosm","priority":0,"user_mail":"elettronicaopensource@gmail.com"}
usersDict["onos_node"]={"pw":"onos","mail_control_password":"onosm","priority":99,"user_mail":"elettronicaopensource@gmail.com"}
usersDict["marco"]={"pw":"1234","mail_control_password":"onosm","priority":0,"user_mail":"elettronicaopensource@gmail.com"}




online_usersDict["marco"]={"pw":"1234","mail_control_password":"onosm","priority":0,"user_mail":"elettronicaopensource@gmail.com"}


usersDict.update(online_usersDict) #insert the online users in the local dictionary



onos_mail_conf={"mail_account":"electronicflame@gmail.com","pw":"fanticgmail","smtp_port":"587","smtp_server":"smtp.gmail.com","mail_imap":"imap.gmail.com"}




#localhost/setup/node_manager/onosRouterGL0001
hardwareModelDict["RouterGL"]={"hwName":"RouterGL","max_pin":5,"hardware_type":"gl.inet_only","pin_mode":{},"timeout":180}
hardwareModelDict["RouterGL"]["pin_mode"]["sr_relay"]={"socket":[(20,19)]}
hardwareModelDict["RouterGL"]["pin_mode"]["digital_input"]={"d_sensor":[(21)]}
hardwareModelDict["RouterGL"]["pin_mode"]["digital_output"]={"button":[(18),(22)]}


hardwareModelDict["ProminiA"]={"hwName":"ProminiA","max_pin":18,"hardware_type":"arduino_promini","pin_mode":{},"timeout":180}
hardwareModelDict["ProminiA"]["pin_mode"]["digital_input"]={"d_sensor":[(2),(3),(4)]}
hardwareModelDict["ProminiA"]["pin_mode"]["digital_output"]={"button":[(5),(6),(7),(8),(9)]}
#hardwareModelDict["ProminiA"]["pin_mode"]["analog_input"]={"a_sensor":[(14),(15),(16),(17),(18),(19)]}
#hardwareModelDict["ProminiA"]["pin_mode"]["servo_output"]={"servo":[(5),(6)]}
#hardwareModelDict["ProminiA"]["pin_mode"]["analog_output"]={"a_out":[(11),(10)]}

hardwareModelDict["Plug6way"]={"hwName":"Plug6way","max_pin":18,"hardware_type":"arduino_promini","pin_mode":{},"timeout":70}
hardwareModelDict["Plug6way"]["pin_mode"]["sr_relay"]={"socket":[(2,3),(4,5),(6,7),(8,9),(14,15),(16,17)],"wifi":[(16,17)]}




# note that in the format ["analog_output"]={"a_out":[(11),(10)]}  
# "a_out" is only the the html name that onos will add to the webobject name
#so the final webobject name will be for example a_out0_ProminiA0001  
#the web object type will be "analog_output"


hardwareModelDict["RouterRB"]={"hwName":"RouterRB","max_pin":15,"hardware_type":"rasberry_b_rev2_only","pin_mode":{},"timeout":180}
hardwareModelDict["RouterRB"]["pin_mode"]["digital_output"]={"button":[(2),(3),(4),(7),(8),(9),(10),(23),(24),(25),(27)]}
hardwareModelDict["RouterRB"]["pin_mode"]["digital_input"]={"d_sensor":[(0),(1),(2),(3),(4),(5),(6)]}
hardwareModelDict["RouterRB"]["pin_mode"]["sr_relay"]={"socket":[(11,17),(18,22)]}


#to see how to setup an arduino you can read
#/usr/share/arduino/hardware/arduino/variants/standard/pins_arduino.h

#hardwareModelDict contain the hardware model for each hardware , each new hardware can be created modding 
#the harware_model.json file

#option for obj_type :
# sr_relay:  latch relay where the first pi in the tuple is set and the second is reset
# digital_output: output digital pins 
# digital_input : input  digital pins
# analog_input  : analog input
# servo_output  : servomotor control pin
# analog_output    : pwm output pin
# time  : containing a int with a time
# numeric_var:   containing a numeric float varaible 
# string_var :   containing a utf8 string varaible 
# serial_output : serial output , allow to write to a serial port 
# serial_input  : serial input  , allow to read  a serial port
# special_pin   : handled on the node arduino firmware side




#option for hardware_type
#arduino_2009
#arduino_promini
#arduino_uno
#arduino_mega1280
#arduino_mega2560
#gl.inet
#rasberry_b_rev2_only


#timeout:    is the time (in seconds) onos will let pass without contact with the node after which the node will be setted as inactive 


#to get the list of varius type used in a harware configuration:
#print hardwareModelDict["onosProminiA"]["pin_mode"].keys()
#print hardwareModelDict["onosPlug6way"]["pin_mode"].keys()
#to get the pin used in a specific mode:
#print hardwareModelDict["onosProminiA"]["pin_mode"]["digital_input"]


# To  get the max pin used for the  onosPlug6way  hardware you have to write:
#  print hardwareModelDict["onosPlug6way"]["max_pin"]
# 
# To get the hardware type for a hardware:
#  print hardwareModelDict["onosPlug6way"]["hardware_type"]
#
#












def getListUsedPinsByHardwareModel(hwName):#get all the pins used by a hardware model
  print "executed getListUsedPinsByHardwareModel"

  if hwName not in hardwareModelDict.keys(): #if the hardware model doesn't exist
    print "the hardware model "+hwName+" doesn't exist"
    return(-1)
  pin_list=[]
  for a in hardwareModelDict[hwName]["pin_mode"].keys():
    #an example of a value is  "digital_output"
    for b in hardwareModelDict[hwName]["pin_mode"][a]:
      #an example of b value is d_sensor
      for c in hardwareModelDict[hwName]["pin_mode"][a][b]:
        #an example of c value is 13  but if the hwtype is sr_relay then an example is (2,3)
        if type(c) in (tuple, list):  #check if is a list or not
          for d in c:  # for every pin of the list 
            #print d
            pin_list.append(d)
        else:  #is not a list  
          pin_list.append(c)


  print "pin used:"
  print pin_list
  return (pin_list)



def getListPinsConfigByHardwareModel(hwName,pin_mode):
  print "executed getListPinsConfigByHardwareModel ()"
  if hwName not in hardwareModelDict.keys(): #if the hardware model doesn't exist
    print "the hardware model "+hwName+" doesn't exist"
    return([])
  if pin_mode not in hardwareModelDict[hwName]["pin_mode"].keys(): #if the type  doesn't exist in the hardware model 
    print "the hardware type "+pin_mode+" doesn't exist in this hardware model"
    return([])
 # else:
 #   print ( "the hardware type "+pin_mode+" Exist in this hardware model")
 


  pin_list=[]
  for a in hardwareModelDict[hwName]["pin_mode"][pin_mode]:  #extract a list of all the pin to use as pin_mode
    for b in hardwareModelDict[hwName]["pin_mode"][pin_mode][a]:
      if type(b) in (tuple, list):
        for c in b:
        #an example of b value is d_sensor
          print c
          pin_list.append(c)
      else:
        pin_list.append(b)

 
  return(pin_list) 
