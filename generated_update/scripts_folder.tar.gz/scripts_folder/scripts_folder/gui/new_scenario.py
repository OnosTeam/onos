# -*- coding: UTF-8 -*-



html='''<!-- pezzo standard per header menu e nome pagina -->

<!DOCTYPE html>

<html>

    <head>
	<link rel="stylesheet" href="../../css/new_scenario.css">
	<meta charset="utf-8">

    </head>
    <body>

	<div id="container-image">
       <img id="image" src="../../img/header.jpg" class="image" />
	</div>




		<div id="container">
			<div id="play"  class="button" ><a href="/"><img class="flex" src="/img/home.png" class="image" /></a></div>
			<div id="teach" class="button" ><a href="/scenarios_list/"><img class="flex" src="/img/scenario-ico.png" class="image" /></a></div>
			<div id="setup" class="button" ><a href="/setup/"><img class="flex" src="/img/setup-ico.gif" class="image" /></a></div>
		</div>



		<div class="divisorio">CREA NUOVO SCENARIO</div>


		
		<div id="body2">
<!--fine pezzo standard per header menu e nome pagina -->





	<div id="container-checkbox">
			<div id="enabled"  class="testo" >Enabled</div>
				<form>
				<input id="enabling" type="checkbox" checked>
				<label id="check" for="enabling"></label>
				</form>


 '''








end_html='''<div id="footer"></div>	</div> </body></html> '''


web_page=html+end_html















