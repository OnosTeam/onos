# -*- coding: UTF-8 -*-
import codecs
obj_name_list=zone["objects"]   


with codecs.open("css/play-zone.css",'r',encoding='utf8') as g:
    css_file = g.read()
    css_play_zone=css_file
g.close()  
 


play_zone_start_html='''<!doctype html><html><head><!--onos_automatic_meta--><!--onos_automatic_page--><title>ONOS</title><!--onos_automatic_javascript--><style type="text/css">  '''+css_play_zone+'''
<!--onos_automatic_body_style-->
    </style>
</head>
<body>
<div id="buttons">
<a href="/"><div id="home">HOME</div></a>
  <a href="/zone_list"><div id="back">BACK</div></a>   
</div>
 <div id="ReloadThis" >'''


web_page=play_zone_start_html+ '''<div id="header">'''+room.upper()+'''</div>'''


col =0
for a in obj_name_list :      # for every web_obj in the room

  if col==0:
    web_page=web_page+'''<div id="riga"> <a <!--onos_automatic_object_a-->><div id="ogg1" <!--onos_automatic_local_style--> ><!--onos_automatic_object_html--></div></a><a <!--onos_automatic_object_a-->><div id="ogg2" <!--onos_automatic_local_style--> ><!--onos_automatic_object_html--></div></a><a <!--onos_automatic_object_a-->><div id="ogg3" <!--onos_automatic_local_style--> ><!--onos_automatic_object_html--></div></a><a <!--onos_automatic_object_a-->><div id="ogg4" <!--onos_automatic_local_style--> ><!--onos_automatic_object_html--></div></a></div>'''
        
  if col==3:
    col=0
  else:
    col=col+1  
  

web_page=web_page+'''</div><!--end reload--></body></html>''' #the closing div is for the reload_page_indicator div
