# -*- coding: UTF-8 -*-



html='''scenario_to mod is: '''+scenario_to_mod




end_html='''<div id="footer"></div>	</div> </body></html> '''


web_page=html+end_html















