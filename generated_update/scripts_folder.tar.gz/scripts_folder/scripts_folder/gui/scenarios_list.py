# -*- coding: UTF-8 -*-



html='''<!DOCTYPE html>

<html>

    <head>
	<link rel="stylesheet" href="../css/scenarios.css">
	<meta charset="utf-8">

    </head>
    <body>

	<div id="container-image">
       <img id="image" src="../img/header.jpg" class="image" />
	</div>




		<div id="container">
			<div id="play"  class="button" ><a href="/"><img class="flex" src="/img/home.png" class="image" /></a></div>
			<div id="teach" class="button" ><a href="/scenarios_list/"><img class="flex" src="/img/scenario-ico.png" class="image" /></a></div>
			<div id="setup" class="button" ><a href="/setup/"><img class="flex" src="/img/setup-ico.gif" class="image" /></a></div>
		</div>



		<div class="divisorio">LISTA SCENARI</div>


	<div id="body2">
<!--fine pezzo standard per header menu e nome pagina -->

		<div class="nuovo-container"><a href="/scenarios_list/new_scenario/">

			<div class="nuovo-testo">NUOVO SCENARIO</div>
			<div id="nuovo-image"><img class="flex" src="../img/croce.png" class="image" /></div>


		</a>
		</div>
 '''





for scenario in scenarioDict.keys() :

  html=html+'''<div class="scenario-container">
			<div class="scenario"><a href="/scenarios_list/mod_scenario/'''+scenario+'''">'''+scenario+'''</a></div>
			<div id="setup-scenario"><a href="#"><img class="flex" src="../img/wrench.png" class="image" /></a></div>
		</div>'''






end_html='''<div id="footer"></div>	</div> </body></html> '''


web_page=html+end_html















