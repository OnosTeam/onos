# -*- coding: UTF-8 -*-


web_page="cgi_test2 ok"






