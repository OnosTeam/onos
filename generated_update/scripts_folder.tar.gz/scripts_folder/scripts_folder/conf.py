
#   Copyright 2014 Marco Rigoni                                               #
#   ElettronicaOpenSource.com   elettronicaopensource@gmail.com               #
#   This program is free software: you can redistribute it and/or modify      #
#   it under the terms of the GNU General Public License as published by      #
#   the Free Software Foundation, either version 3 of the License, or         #
#   (at your option) any later version.                                       # 
#																			  #
#   This program is distributed in the hope that it will be useful,           #
#   but WITHOUT ANY WARRANTY; without even the implied warranty of            #
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             #
#   GNU General Public License for more details.                              #
#                                                                             #
#   You should have received a copy of the GNU General Public License         #
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.     #


import globalVar
from web_object import *
import router_handler
import hw_node




global exit   #if exit ==1 all the program stop and exit
global object_dict
global zoneDict
global nodeDict
global hardwareModelDict
global scenarioDict


router_hardware=hardwareModelDict[router_hardware_type]


hardware_labels=hardwareModelDict.keys()
#hardware_labels=["onosPlug6way","onosPlug2way","onosTsensorA","onosTsensorB","onosIRcmdAAA","onosProminiA"]

#router_sn is in globalVar.py

hardware=router_handler.RouterHandler(router_hardware,router_sn)



print "router hardware selected is"+router_hardware_type


def newDefaultWebObj(name):
  return(WebObject(name,"b",0,{u"0":"background-color:green;",u"1":"background-color:red;"},{u"0":name+u"=0",u"1":name+u"=1"},{}," ",[9999],9999,{}))


def newDefaultWebObjBody(name):
  return(WebObject(name,"b",0,{u"0":"background-color:#A9E2F3;",u"1":"background-color:#8181F7;"},{u"0":name+u"=0",u"1":name+u"=1"},{}," ",[9999],9999,{}))




object_dict={} #object_dict  contain all the web_object  and the key of the dictionary for each web_object is the name of the web_object

objectList=[]
roomList=[]
zoneDict={}#dict where the key is the name from roomList and the value is a list of all the webobject names present in the room  


object_dict["minutes"]=newDefaultWebObj("minutes")
object_dict["hours"]=newDefaultWebObj("hours")
object_dict["day"]=newDefaultWebObj("day")
object_dict["month"]=newDefaultWebObj("month")
object_dict["year"]=newDefaultWebObj("year")
object_dict["dayTime"]=newDefaultWebObj("dayTime")  #hours of the day expressed in minutes



def GetfirstFreeNodeAddress(tmpnodeDictionary):  #  return the first free address like a dhcp server..banana not used 
# because i use a real dhcp on the gl.inet or in the main router
  print "GetfirstFreeNodeAddress() executed"
  i=2
  free_address=0
  while free_address==0:
    for b in tmpnodeDictionary.keys():
      a=tmpnodeDictionary[b]  
      if a.getNodeAddress()!=i:
        free_address=i
      else:
        free_address=0
        i=i+1
  if free_address < 254: 
    return (free_address)
  else:
    print "all node address used , from 0 to 253"
    return (-1) 






#base_cfg_path is in globalVar.py

def readDictionaryFromSavedFile(key):
  print "readDictionaryFromSavedFile() executed to read: "+str(key)
  json_file = codecs.open(base_cfg_path+"config_files/data.json",'r',"utf8")
  readed_data = json_file.read()
  json_file.close() 
  readed_dict=json.loads(readed_data)
  
  return(readed_dict[key])

def readConfigurationsFromSavedFile(key):
  print "readConfigurationsFromSavedFile() executed to read: "+str(key)
  cfg_json_file = codecs.open(base_cfg_path+"config_files/cfg.json",'r',"utf8")
  cfg_readed_data = cfg_json_file.read()
  cfg_json_file.close() 
  data=json.loads(cfg_readed_data)
  
  return(data[key])



def importConfig():
  global zoneDict
  global nodeDicts
  global scenarioDict
  global accept_only_from_white_list  
  global enable_mail_service
  global logTimeout 
  global login_required 
  global mail_whiteList
  global online_server_enable
  global online_usersDict
  global timezone
  global enable_onos_auto_update

  accept_only_from_white_list=readConfigurationsFromSavedFile(u"accept_only_from_white_list")  
  enable_mail_service=readConfigurationsFromSavedFile(u"enable_mail_service")  
  logTimeout=readConfigurationsFromSavedFile(u"logTimeout")  
  login_required=readConfigurationsFromSavedFile(u"login_required")  
  mail_whiteList=readConfigurationsFromSavedFile(u"mail_whiteList")  
  online_server_enable=readConfigurationsFromSavedFile(u"online_server_enable")  
  online_usersDict.update(readConfigurationsFromSavedFile(u"online_usersDict"))  
  timezone=readConfigurationsFromSavedFile(u"timezone")  
  enable_onos_auto_update=readConfigurationsFromSavedFile(u"enable_onos_auto_update")  

  zoneDict.update(readDictionaryFromSavedFile(u"roomDictionary"))
  scenarioDict.update(readDictionaryFromSavedFile(u"scenarioDictionary"))
  tmp_obj_dict=readDictionaryFromSavedFile(u"objectDictionary")

  for a in tmp_obj_dict.keys():  #for each object in the file
    object_html_name=a
    object_type=tmp_obj_dict[a][u"type"]
    object_start_status=tmp_obj_dict[a][u"status"]
    object_styleDict=tmp_obj_dict[a][u"styleDict"]
    object_style0=object_styleDict[u"0"]
    object_style1=object_styleDict[u"1"]
    object_htmlDict=tmp_obj_dict[a][u"htmlDict"]
    object_html0=object_htmlDict[u"0"]
    object_html1=object_htmlDict[u"1"]
    object_cmdDict= tmp_obj_dict[a][u"cmdDict"]
    object_command0=object_cmdDict[u"0"]
    object_command1=object_cmdDict[u"1"]
    object_init_command=object_cmdDict[u"s_cmd"]
    object_notes=tmp_obj_dict[a][u"notes"]
    object_hardware_pins=tmp_obj_dict[a][u"pins"]
    object_node_serial_number=tmp_obj_dict[a][u"node_sn"]
    object_scenarios=tmp_obj_dict[a][u"scenarios"]
    object_priority=tmp_obj_dict[a][u"priority"]
    object_permission=tmp_obj_dict[a][u"perm"]
    object_owner=tmp_obj_dict[a][u"own"]
    object_group=tmp_obj_dict[a][u"grp"]
    object_mail_report_list=tmp_obj_dict[a][u"mail_l"]


    if (object_start_status=="inactive"):  #prevent the node to been setted as inactive
      object_start_status=0       

    objectList.append(WebObject(object_html_name,object_type,object_start_status,object_styleDict,object_htmlDict,object_cmdDict,object_notes,object_hardware_pins,object_node_serial_number,{u"scenarios":object_scenarios,u"priority":object_priority,u"perm":object_permission,u"own":object_owner,u"grp":object_group,u"mail_l":object_mail_report_list}))
    #create a new webobject with the data collected from the file and append it to objectList



  tmp_node_dict=readDictionaryFromSavedFile("nodeDictionary")
  for a in tmp_node_dict.keys():  #for each node in the file
    node_serial_number=tmp_node_dict[a]["node_serial_number"]
    node_type=tmp_node_dict[a]["hwModelName"]
    #node_sn=tmp_node_dict[a]["node_serial_number"]
    node_address=tmp_node_dict[a]["nodeAddress"]   
    hardware_node_type=hardwareModelDict[node_type]
    nodeDict[node_serial_number]=hw_node.HwNode(node_serial_number,hardware_node_type,node_address,router_hardware_fw_version)  
  #ricreate the nodeDict from the json backup
  #note that the io config will be done in webserver.py where i add the objectList elements to object_dict






importConfig()

object_dict["onosCenterWifi"]=newDefaultWebObj("onosCenterWifi")  #turn on or off wifi
#object_dict["wifi0_Plug6way0001"]=newDefaultWebObj("wifi0_Plug6way0001")  #turn on or off wifi
object_dict["onosCenterWifi"].setCommand0("uci set wireless.radio0.disabled=1&uci commit wireless && wifi")
object_dict["onosCenterWifi"].setCommand1("uci set wireless.radio0.disabled=0&uci commit wireless && wifi")

object_dict["counter1"]=newDefaultWebObj("counter1")  #count

#zoneDict[router_sn]["objects"].append("OnosCenterWifi")





