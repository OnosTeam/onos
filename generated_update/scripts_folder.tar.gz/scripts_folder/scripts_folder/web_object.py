
#   Copyright 2014 Marco Rigoni                                               #
#   ElettronicaOpenSource.com   elettronicaopensource@gmail.com               #
#   This program is free software: you can redistribute it and/or modify      #
#   it under the terms of the GNU General Public License as published by      #
#   the Free Software Foundation, either version 3 of the License, or         #
#   (at your option) any later version.                                       # 
#																			  #
#   This program is distributed in the hope that it will be useful,           #
#   but WITHOUT ANY WARRANTY; without even the implied warranty of            #
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             #
#   GNU General Public License for more details.                              #
#                                                                             #
#   You should have received a copy of the GNU General Public License         #
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.     #

#note  i put "banana" where there is code to modify in the next release

#import os

from globalVar import *           # import parameter globalVar.py
global exit  #if exit ==1 all the program stop and exit

global router_hardware_type









class WebObject:

    global exit  #if exit ==1 all the program stop and exit
    __object_type="b"   #alternative is "s" for status viewer or "t" for timer button  or "sb" for static button  

    __function0=""     
    __function1="" 
    __init_function="" 
    __hw_node_name="local"         #by default the hw_node is the arduino connected to the pc by usb serialport
   
   


    def __init__(self,name,obj_type="b",start_status=0,styleDictionary={},htmlDictionary={},cmdDictionary={},note=" ",hardware_pin=[9999],HwNodeSerialNumber=0,spareDict={}):
      self.__object_type=obj_type
      self.__style0="background-color:green ;"
      self.__style1="background-color:red ;"
      self.styleDict={u"0":self.__style0,u"1":self.__style1,u"wait":"background-color:grey ;color black","default_s":"background-color:red ;color black"}
      self.styleDict.update(styleDictionary)
      self.__style0=self.styleDict[u"0"]
      self.__style1=self.styleDict[u"1"]
      self.style_wait=self.styleDict[u"wait"] #banana to remove

      self.htmlDict={u"0":name+"=0",u"1":name+"=1"}

      self.htmlDict.update(htmlDictionary)

      self.html0=self.htmlDict["0"]     
      self.html1=self.htmlDict["1"]  
      self.html_wait=name+u"WAIT"  
      self.html_error=name+u"has status_not_valid"





      self.cmdDict={u"0":"",u"1":"",u"s_cmd":""}
      self.cmdDict.update(cmdDictionary)
      self.__function0=self.cmdDict[u"0"]   #banana to remove
      self.__function1=self.cmdDict[u"1"]   #banana to remove
      self.init_function=self.cmdDict[u"s_cmd"]
      self.html_name=name


      self.required_priority=0
      self.permissions="111111111"
      self.owner="onos_admin" #name of the owner
      self.group=["web_interface","onos_mail_guest"] #list of users that can change the webobject
      self.mail_report_list=[] #list of mail to send the report

      try:
        self.attachedScenarios=list(set(self.attachedScenarios + spareDict["scenarios"]))
      except:
        self.attachedScenarios=[]  #list of attached scenarios  

      try:
        self.required_priority=spareDict["priority"]
      except:
        self.required_priority=0   


      try:
        self.permissions=spareDict["perm"]
      except:
        self.permissions="111111111" 


      try:
        self.owner=spareDict["own"]
      except:
        self.owner="onos_admin" #name of the webobject owner 


      try:
        self.group=list(set(self.group + spareDict["grp"]))
      except:
        self.group=["web_interface","onos_mail_guest"] #list of users that can change the webobject
 

      try:
        self.mail_report_list= list(set(self.mail_report_list + spareDict["mail_l"])) 
      except:
        self.mail_report_list=[] #list of mail to send the report
 

      self.start_status=start_status
      self.status=0
      self.previous_status=self.status          
      self.note=note
      self.attachedPins=hardware_pin          #arduino pin associated with the web object 
      self.HwNodeSerialNumber=HwNodeSerialNumber
      self.arduinoWriteError=0
      #self.analog_threshold=512
      #self.__hw_node_name="rasberry_b_rev2_only"  #banana to remove
      self.simply_digital_output_group=["digital_output","b","button"] #makes alias
      self.general_digital_output_group=self.simply_digital_output_group+["sr_relay"]
      self.general_analog_output_group=["analog_output","servo_output","numeric_var"]
      self.general_out_group=self.general_digital_output_group+self.general_analog_output_group+["string_var"] #all output
      self.simply_digital_input_group=["d_sensor","digital_input"]     #make alias
      self.analog_value_general_group=["analog_output","analog_input","servo_output","numeric_var"]#objtype with num values

      self.isActive=1 #tell onos if the web_object is connected or not


     # os.system("echo classe >> numero_oggetti_classe_webobject.txt")

    def InitFunction(self):
      os.system(self.init_function+'> logs/cmd_init.log 2>&1 &')
      print self.init_function
      print ""
      if (self.status==0):
        os.system(self.__function0+'> logs/cmd0.log 2>&1 &')
        print self.__function0
      else:
        os.system(self.__function1+'> logs/cmd1.log 2>&1 &')
        print self.__function1
      


    def setStatus(self,status):  # set the new status and execute the relative command
        result=0 #banana  to remove 
        a=0
        #if (self.status==status):
        #  print "the status to set in web_object.py is equal to the previus one so i did nothing"
        #  return(1) 

        if (status=="inactive"):
          self.previous_status=self.status 
          self.status=status
          return(1)  

        if (status==0.5):
          self.previous_status=self.status 
          self.status=status
          return(1) 

        if (self.__object_type in self.simply_digital_output_group):  #normal button  like an arduino digital write controlled by web interface 
          if (status==1)|(status=="1"): #executed only if there is a change in the status from something to 1
            os.system(self.__function1+'> logs/cmd1.log 2>&1 &')
            if self.attachedPins[0]!=9999 :
              print 'i try to set pin number'+str(self.attachedPins[0])+'to'+str(status)

          if (status==0)|(status=="0"):     #executed only if there is a change in the status from something to 0
            os.system(self.__function0+'> logs/cmd0.log 2>&1 &')
            if self.attachedPins[0]!=9999 :
              print 'i try to set pin number'+str(self.attachedPins[0])+'to'+str(status)

          self.previous_status=self.status 
          self.status=status
          return(1)

        if (self.__object_type=="sb"):  #static button   digital output button that don't  change the web page once pressed
            os.system(self.__function0+'> logs/cmd0.log 2>&1 &')
            if self.attachedPins[0]!=9999 :
              print 'i try to set pin number'+str(self.attachedPins[0])+'to'+str(status)

            return(1)



        if (self.__object_type=="sr_relay"):  # latch relay  with 2 coil  one to set  one to reset 
          result=1   #banana     to remove in the future
          if (len(self.attachedPins)!=2) :
            print "can't set the relay because i don't have two pin attached"
            return(-1)
          if ( status==1): #executed only if there is a change in the status from 0 to 1
            os.system(self.__function1+'> logs/cmd1.log 2>&1 &')
           # if (self.attachedPins[0]!=9999)&(self.attachedPins[1]!=9999) :


          if (status==0):     #executed only if there is a change in the status from 1 to 0
            os.system(self.__function0+'> logs/cmd0.log 2>&1 &')
            #if (self.attachedPins[0]!=9999)&(self.attachedPins[1]!=9999) :
          self.previous_status=self.status 
          self.status=status
          return(1)


        if (self.__object_type in self.simply_digital_input_group):  #digital sensor like read digital pin status  with digitalRead() on arduino
          if (status==1):    #executed only if there is a change in the status from 0 to 1
            print "readed a status change from 0 to 1 .saved in the class"
            os.system(self.__function1+'> logs/cmd1.log 2>&1 &')
            self.status=1
            result=1   #banana     to remove in the future

          if (status==0):     #executed only if there is a change in the status from 1 to 0
            print "readed a status change from 1 to 0 .saved in the class"
            os.system(self.__function0+'> logs/cmd0.log 2>&1 &')
            self.status=0
            result=1   #banana     to remove in the future
          self.previous_status=self.status 
          self.status=status
          return(1)



        if (self.__object_type=="a_sensor")or(self.__object_type=="analog_input"): 
          if self.status!=status:
            self.previous_status=self.status 
            self.status=status
            print "analog state changed to "+str(self.status)

          else:
            print "analog state not changed from "+str(self.status)


        return(result)   #banana     to remove in the future

    def setHwNodeSerialNumber(self,HwNodeSerialNumber):  # set the hwnode address

      self.HwNodeSerialNumber=HwNodeSerialNumber
      return(1)   

    def getHwNodeSerialNumber(self):  # get the hwnode serial number     
      return(self.HwNodeSerialNumber)   

 #   def getHwNodeName(self):  # get the hwnode     
 #     return(self.__hw_node_name)  

    def getObjActivity(self):
      return(self.isActive)

    def setObjActivity(self,value):   
      self.isActive=value  
      return()


    def getNotes(self):
        return(self.note)


    def setNotes(self,note):
        self.note=note 
        return(self.note)

    def getStatus(self):
        return(self.status)


    def getStatusForScenario(self):
        if type(self.status) == type(''):
          return('"'+self.status+'"')  # return    "inactive"  to use it in eval...
        return(self.status)

    def getPreviousStatusForScenario(self):
        if type(self.status) == type(''):
          return('"'+self.status+'"')  # return    "inactive"  to use it in eval...
        return(self.status)

    def getStartStatus(self):
        return(self.start_status)

    def getPreviousStatus(self):
        return(self.previous_status)



    def getStyle(self):             #return the actual style  of the button
        if (self.status==0)|(self.status=="0"):
          return(self.styleDict[u"0"])
        if (self.status==0.5):
          return(self.style_wait) 
        if (self.status==1)|(self.status=="1"):
          return(self.styleDict[u"1"])

        try:
          return(self.styleDict[self.status])
        except:
          return(self.styleDict[u"default_s"])

     #   if (self.status>self.analog_threshold): # for analog type
     #     return(self.__style1)
     #   else:
     #     return(self.__style0)


    def getOtherStyle(self):             #return the opposite  style  respect the actual  of the button
        if (self.status==1)|(self.status=="1"):
          return(self.__style0)
        if (self.status==0.5):
          return(self.style_wait) 
        if (self.status==0)|(self.status=="0"):
          return(self.__style1)

      #  if (self.status<self.analog_threshold): # for analog type
      #    return(self.__style1)
      #  else:
      #    return(self.__style0)

          
          
    def getStyle0(self):             #return the static style0  of the button
          return(self.__style0)



    def setStyle0(self,style):             #set the static style0  of the button
          self.__style0=style
          return(self.__style0)


    def setStyle1(self,style1):             #set the static style1  of the button
          self.__style1=style1
          return(self.__style1)


    def getStyle1(self):             #return the static style1  of the button
          return(self.__style1)
   
   
    
    
    def getHtml(self):             #return the opposite  html  respect the actual  of the web object
        if (self.status==0)|(self.status=="0"):
          return(self.htmlDict[u"0"])
        if (self.status==0.5):
          return(self.html_wait) 
        if (self.status==1)|(self.status=="1"):
          return(self.htmlDict[u"1"])   
        return (self.html_name+u"="+str(self.status)) #for analog type
          
          
    def getOtherHtml(self):             #return the opposite  html  respect the actual  of the web object ,obsolete
        if (self.status==1)|(self.status=="1"):
          return(self.html0)
        if (self.status==0.5):
          return(self.html_wait) 
        if (self.status==0)|(self.status=="0"):
          return(self.html1)
        return (str(self.status)) #for analog type


    def getHtml0(self):             #return the static html0  of the button
          return(self.html0)


    def getHtml1(self):             #return the static html1  of the button
          return(self.html1)


    def setHtml0(self,html0):             #set the static html0  of the button
          self.html0=html0
          self.htmlDict["0"]=html0 
          return(self.html0)

    def setHtmlWait(self,html_w):             #set the static html0  of the button
          self.html_wait=html_w
          return(self.html_wait)


    def setHtml1(self,html1):             #set the static html1  of the button
          self.html1=html1
          self.htmlDict["1"]=html1 
          return(self.html1)



    def getCommand0(self):             #return the static command0  of the button
          return(self.__function0)

    def setCommand0(self,command0):             #set the static command0  of the button
          self.__function0=command0
          return(self.__function0)


    def getCommand1(self):             #return the static command1  of the button
          return(self.__function1)


    def setCommand1(self,command1):             #set the static command0  of the button
          self.__function1=command1
          return(self.__function1)


    def removeAttachedScenario(self,scenario):             #attaches a scenario to this webobject 
      if scenario in self.attachedScenarios:
        self.attachedScenarios.remove(scenario)


    def attachScenario(self,scenario):             #attaches a scenario to this webobject 
      print "scenario attached"
      if scenario not in self.attachedScenarios:
        self.attachedScenarios.append(scenario)
      return(1)


    def getListAttachedScenarios(self):
      return (self.attachedScenarios) 


    def getInitCommand(self):             #return the static init_command  of the button
          return(self.init_function)


    def setInitCommand(self,init_command):             #set the static init_command  of the button
          self.init_function=init_command
          return(self.init_function)



    def setAttachedPin(self,pin):
      self.attachedPins[0]=pin
      self.setType(self.__object_type)
      return (self.attachedPins[0])

    def getAttachedPinList(self):
      return (self.attachedPins)




    def validateStatusToSetObj(self,status):
 #return 1 if the status is compatible with the webobject type and is an output or variable ..
 #return 2 if the status is compatible with the webobject type and is an input
 #return -1 otherwise 
      is_number=0 
      is_output=0
      if status=="inactive":
        return(1)

      try:
        status=float(status)
        is_number=1 
      except:
        print "the mail status value passed is not a number is:"+str(status)+"end"
        errorQueue.put("the mail status value passed is not a number is:"+str(status)+"end" )
        print "is"+str(status)
        is_number=0

      if (self.__object_type in self.general_out_group ):
        is_output=1

      if (self.__object_type in self.general_digital_output_group )|(self.__object_type in self.simply_digital_input_group):  #only binary
        if is_number==1:  #the value is a number   
        
          if (status>1)|(status<0): # not binary data
            return (-1)

          if is_output==1:
            return(1)
          else:
            return(2)#is input

        else:
          return(-1)  #not a number





      obj_general_type=object_dict[objname].getGeneralType()
      if self.__object_type in self.analog_value_general_group: # the value must be a float or binary one
        if is_number==1:  #the value is a number      
          if is_output==1:
            return(1)
          else:
            return(2)

        else:
          return(-1)  #not a number
    


      if self.__object_type=="string_var": #text
        return (1)



    def getPermissions(self):
      tmp1=int(self.permissions[0])+int(self.permissions[1])+int(self.permissions[2])   #get 7 from  "111"
      tmp2=int(self.permissions[3])+int(self.permissions[4])+int(self.permissions[5])
      tmp3=int(self.permissions[6])+int(self.permissions[7])+int(self.permissions[8])
      perm=str(tmp1)+str(tmp2)+str(tmp3) 
      return(perm)


    def checkPermissions(self,user,action,priority):  #check the permission for the user and action passed
      if (self.getPermissions()=="777") |(priority==10)|(priority==99) :
        return (1)

      if action=="r":
        if user == self.owner:  #the user is owner
          if  self.permissions[0]=="1" :  #the owner has read access 
            return (1)
        if user in self.group :  #the user is in the group
          if  self.permissions[3]=="1" :  #the group has read access 
            return (1)

        if  self.permissions[6]=="1" :  #anyone has read access 
          return (1)

        return(-1) #the user has not write access

      if action=="w":
        if user == self.owner:  #the user is owner
          if  self.permissions[1]=="1" :  #the owner has write access 
            return (1)
        if user in self.group :  #the user is in the group
          if  self.permissions[4]=="1" :  #the group has write access 
            return (1)

        if  self.permissions[7]=="1" :  #anyone has write access 
            return (1)

        return(-1) #the user has not write access 


      if action=="x":
        if user == self.owner:  #the user is owner
          if  self.permissions[2]=="1" :  #the owner has write access 
            return (1)
        if user in self.group :  #the user is in the group
          if  self.permissions[5]=="1" :  #the group has write access 
            return (1)

        if  self.permissions[8]=="1" :  #anyone has write access 
          return (1)


        return(-1) #the user has not write access
              
      return(-1) #the user has not write access        







    def setPermissions(self,perm):
      perm=bin(int(perm[0]))[2:]+bin(int(perm[1]))[2:]+bin(int(perm[2]))[2:]  #get "111 111 111"  from "777"
      self.permissions=str(perm)
 
      return(self.permissions)


    def setOwner(self,owner):
      self.owner=owner
      return(self.owner)

    def getOwner(self):
      return(self.owner)

    def addToGroup(self,username):
      if username not in self.group:
        self.group.append(username)
      return(self.group)

    def removeFromGroup(self,username):
      if username in group :
        self.group.remove(username)

      return(self.group)


    def getMailReport(self):
      print "report mail list:",self.mail_report_list 
      return(self.mail_report_list)


    def setMailReport(self,mail_to_add_to_list): #add a list of mails to witch onos will send notes about this objec
      self.mail_report_list=self.mail_report_list+mail_to_add_to_list
      self.mail_report_list=list(set(self.mail_report_list))
      print "set mail report",self.mail_report_list
      return(self.mail_report_list)

    def getGroup(self):
      return(self.group)


    def setRequiredPriority(self,priority):
      self.required_priority=priority
      return(self.required_priority)

    def getRequiredPriority(self):
      return(self.required_priority)

    def checkRequiredPriority(self,agent_priority):  #retutn -1 if the priority the agent has is les than required
      if agent_priority<self.required_priority:
        print "error ,required priority is "+str(self.required_priority)
        errorQueue.put("error ,required priority is "+str(self.required_priority) ) 
        return(-1)
      else:
        return(1)



    def getType(self):
      return(self.__object_type)

    def setType(self,current_type):
      self.__object_type=current_type
      #if (self.__object_type=="d_sensor"):
        #hardware.setPinMode(self.__hw_node_name,self.attachedPins[0],"DINPUT")

    #  if (self.__object_type=="sb"): 
       # hardware.setPinMode(self.__hw_node_name,self.attachedPins[0],"DOUTPUT") banana

   #   if (self.__object_type=="b"): 
       # hardware.setPinMode(self.__hw_node_name,self.attachedPins[0],"DOUTPUT")

#to implement  analog sensor  and pwm output  and servo controll

      return(self.__object_type)

    def getName(self):
        return(self.html_name)

    def changeCommand0(self,f0):
        self.__function0=f0
        return(self.__function0)

    def changeCommand1(self,f1):
        self.__function1=f1
        return(self.__function1)

        
    def getObjectDictionary(self):
      tmp_dict={u"objname":self.html_name,u"type":self.__object_type,u"status":self.status,u"styleDict":self.styleDict,u"htmlDict":self.htmlDict,u"cmdDict":self.cmdDict,u"notes":self.note,u"node_sn":self.HwNodeSerialNumber,u"pins":self.attachedPins,u"scenarios":self.attachedScenarios,u"priority":self.required_priority,u"perm":self.permissions,u"own":self.owner,u"grp":self.group,u"mail_l":self.mail_report_list}
      return(tmp_dict)
    

         





