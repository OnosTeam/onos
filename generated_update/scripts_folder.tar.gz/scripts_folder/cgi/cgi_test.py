# -*- coding: UTF-8 -*-
web_page="<h1>webobjects:</h1>"

for a in objectDict.keys():
  web_page=web_page+"<div>"+a+"</div>" 

web_page=web_page+"<h1>zones:</h1>"

for a in zoneDict.keys():
  web_page=web_page+"<div>"+a+"</div>" 

web_page=web_page+"<h1>nodes:</h1>"

for a in nodeDict.keys():
  web_page=web_page+"<div>"+a+"</div>" 

web_page=web_page+"<h1>users:</h1>"

for a in usersDict.keys():
  web_page=web_page+"<div>"+a+"</div>" 






