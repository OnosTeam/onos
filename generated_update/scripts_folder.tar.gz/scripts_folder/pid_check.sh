#!/bin/bash

pid=`pidof python`

kill -9 $pid

