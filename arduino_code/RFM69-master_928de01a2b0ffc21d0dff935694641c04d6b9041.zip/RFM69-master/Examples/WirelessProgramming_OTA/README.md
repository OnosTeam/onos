# Wireless Programming for Moteinos

## How to use
Since v1.5 you can now run this app in several ways:
- natively via the WirelessProgramming.exe GUI app
- the windows GUI can also invoke the OTA.py script via embedded IronPython engine (parameters from GUI pass to the OTA.py script)
- cross platform straight from Python (2.7 runtime) by supplying parameters (run `python OTA.py -h` for details)
<br/>
Make sure to download the entire repo ZIP, not individual files.